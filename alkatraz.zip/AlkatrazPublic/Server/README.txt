There is an admin account setup:

Username: admin
Password: password

It has all the pay items and stuff.

There's a text file in the Alkatraz Client directory
called "serveraddress.txt" you will need users to put
the server ip address in there to connect to your server.


Warning:

This game contains a few spelling mistakes and bugs,
I made this when I was a young boy, 14 or so in VB6
which was all the rage back then. Forgive me.

There's a lot of secrets in the game, your not allowed
to say jesus or jew. You can kill stuff with weapons.
You can trade money. Sit down on the sofas, stuff like
that.

The password to the Biolab is: NEMESIS

I liked resident evil at the time.


Credits:

I borrowed some sounds from the PC game Silver, there's
a tree somewhere in the game from secret of mana and the
midi music I got from some midi music website.

Back then I didnt really have the utilities or understanding
of sound to synthesize my own sound at a decent level of
quality.